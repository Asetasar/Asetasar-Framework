local masterModule = {
    DELETE_INTERNALS_FOLDER = true,
    DELETE_DEPENDENCIES_FOLDER = true,
    DELETE_SINGLETON_FOLDER = true
}

--// Future-proof if other languages are desired for example
function masterModule:GetStringFromStringList(messageType)
    return self.StringList[messageType]
end

function masterModule:FormatByStringList(messageType, ...)
    local stringArray, isEmpty = self._log:SanitizeArrayToString({...})

    if isEmpty then
        return self:GetStringFromStringList(messageType)
    else
        return string.format(self:GetStringFromStringList(messageType), table.unpack(stringArray))
    end

    --// Just don't be a bad coder because I don't want to make this more complex than it already is
end

function masterModule:Log(logType, messageType, ...)
    if not self._log then
        --// Will work because always 1 concated string will be passed
        local errorMessage = {...}
        errorMessage = errorMessage[1]

        error(`[Asetasar master] very internal error, the error in question:\n{messageType}`, 3)
    end

    if not messageType then
        self._log:Log(logType, "[Asetasar master]", ...)
    else
        self._log:Log(logType, "[Asetasar master]", self:FormatByStringList(messageType, ...))
    end
end

function masterModule:_Require(moduleScript)
    return pcall(function()
        return require(moduleScript)
    end)
end

--//
--//    SINGLETON LOADING
--//

function masterModule:GeneratePassDictionary()
    self.PassDict = {
        RunService = game:GetService("RunService"),
        Players = game:GetService("Players"),
        LocalPlayer = game:GetService("Players").LocalPlayer,
        Aseta = self,
        Singletons = self.Singletons
    }
end

function masterModule:GetDefaultPassDict()
    return table.clone(self.PassDict)
end

function masterModule:LoadInternals()
    local internalsFolder = script:WaitForChild("Internals")

    for _, module in internalsFolder:GetChildren() do
        local success, loadedModule = self:_Require(module)

        if not success then
           error(`Failed to load internal [{module}].`)
        end

        for index, value in loadedModule do
            self[index] = value
        end

        --// Just to be sure, not sure about this one
        table.clear(loadedModule)
        loadedModule = nil
    end

    if self["DELETE_INTERNALS_FOLDER"] then
        internalsFolder:Destroy()
    end
end

function masterModule:Load()
    self.IsMaster = true
    self.Script = script

    self:LoadInternals()
    self:FetchLoadDependencies()

    self:GeneratePassDictionary()
    self:LoadSingletons()

    self._log = self.Dependencies["Logger"]


end

return masterModule