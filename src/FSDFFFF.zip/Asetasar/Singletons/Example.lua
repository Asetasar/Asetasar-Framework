local exampleSingleton = {
    ["#Index"] = "Moving",
    ["#Dependencies"] = { "LoggI", "DbgCounter"},
    ["#IgnoreDependencyErrors"] = true
}

function exampleSingleton:AsetaLoad(passThroughDict)
    for index, value in passThroughDict do
        self[index] = value
    end

    table.clear(passThroughDict)

    print("Ff")

    print(self)
end

return exampleSingleton