local singletonHandler = {
    Singletons = {}
}

function singletonHandler:LoadSingleton(_singleton, passThroughDict)
    local success, singleton = self:_Require(_singleton)

    if not success then
        return false, singleton
    end

    local dependencyIndexArray = singleton["#Dependencies"]
    local singletonIndex = singleton["#Index"]
    local ignoreDependencyErrors = singleton["#IgnoreDependencyErrors"]

    if not singletonIndex then
        singletonIndex = singleton.Name
    end

    if dependencyIndexArray then
        local success, errorMessages = self:LoadDependencies(dependencyIndexArray)

        if not success then
            local errorMessageIndex = (#errorMessages == 1) and "FAILED_LOAD_ONE_DEPENDENCY" or
                "FAILED_LOAD_MULTIPLE_DEPENDENCIES"

            self:Log(3, errorMessageIndex, table.concat(errorMessages, "\n"))

            if not ignoreDependencyErrors then
                return false
            end
        end
    end

    for index, dependency in dependencyIndexArray do
        passThroughDict[index] = dependency
    end

    singleton:AsetaLoad(passThroughDict)

    return singleton
end

function singletonHandler:LoadSingletons()
    local singletonsArray = self.Script:WaitForChild("Singletons"):GetChildren()
    local loadCounter = self.Counter:Start()

    for _, _singleton in singletonsArray do
        loadCounter:Reset()

        local success, singleton = self:LoadSingleton(_singleton, self:GetDefaultPassDict())

        if not success then
            self:Log(3, "SINGLETON_FAILED_LOAD", _singleton, singleton)

            continue
        end

        local loadTime = loadCounter:Stop()
        self:Log(1, "SINGLETON_LOADED_TIME", _singleton, loadTime)
    end
end

return singletonHandler